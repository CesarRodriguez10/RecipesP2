const express = require('express')
const Database = require('better-sqlite3')
const app = express()
app.use(express.json())

// Crear/abrir la base de datos
const db = new Database('recipes.db')

// Crear tablas si no existen
db.exec(`
  CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT,
    prep_time INTEGER,
    ingredients TEXT,
    steps TEXT,
    image_url TEXT,
    times_prepared INTEGER DEFAULT 0,
    avg_rating REAL DEFAULT 0,
    opinion_count INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS opinions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recipeId INTEGER,
    comment TEXT,
    rating REAL,
    portions INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
  );
`)

// GET todas las recetas
app.get('/recipes', (req, res) => {
  const recipes = db.prepare('SELECT * FROM recipes').all()
  recipes.forEach(r => {
    r.ingredients = JSON.parse(r.ingredients || '[]')
    r.steps = JSON.parse(r.steps || '[]')
  })
  res.json(recipes)
})

// POST crear receta
app.post('/recipes', (req, res) => {
  console.log('Datos recibidos:', req.body)
  const { name, description, category, prep_time, ingredients, steps, image_url } = req.body
  const stmt = db.prepare(`
    INSERT INTO recipes (name, description, category, prep_time, ingredients, steps, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `)
  const result = stmt.run(
    name,
    description || null,
    category || null,
    prep_time || null,
    JSON.stringify(ingredients || []),
    JSON.stringify(steps || []),
    image_url || null
  )
  res.status(201).json({ id: result.lastInsertRowid })
})

// GET detalle de una receta
app.get('/recipes/:id', (req, res) => {
  const recipe = db.prepare('SELECT * FROM recipes WHERE id = ?').get(req.params.id)
  if (!recipe) return res.status(404).json({ error: 'Not found' })
  recipe.ingredients = JSON.parse(recipe.ingredients || '[]')
  recipe.steps = JSON.parse(recipe.steps || '[]')
  res.json(recipe)
})

// GET opiniones de una receta
app.get('/recipes/:id/opinions', (req, res) => {
  const opinions = db.prepare('SELECT * FROM opinions WHERE recipeId = ?').all(req.params.id)
  res.json(opinions)
})

// POST agregar opinion
app.post('/recipes/:id/opinions', (req, res) => {
  const { comment, rating, portions } = req.body
  const recipeId = parseInt(req.params.id)

  db.prepare(`
    INSERT INTO opinions (recipeId, comment, rating, portions)
    VALUES (?, ?, ?, ?)
  `).run(recipeId, comment || null, rating, portions || null)

  // Actualizar stats de la receta
  const opinions = db.prepare('SELECT * FROM opinions WHERE recipeId = ?').all(recipeId)
  const avg_rating = opinions.reduce((s, o) => s + (o.rating || 0), 0) / opinions.length
  const avg_portions = opinions.reduce((s, o) => s + (o.portions || 0), 0) / opinions.length

  db.prepare(`
    UPDATE recipes
    SET avg_rating = ?, opinion_count = ?, times_prepared = times_prepared + 1
    WHERE id = ?
  `).run(avg_rating, opinions.length, recipeId)

  res.status(201).json({ message: 'Opinión guardada' })
})

// GET stats de una receta
app.get('/recipes/:id/stats', (req, res) => {
  const recipe = db.prepare('SELECT * FROM recipes WHERE id = ?').get(req.params.id)
  if (!recipe) return res.status(404).json({ error: 'Not found' })
  const opinions = db.prepare('SELECT * FROM opinions WHERE recipeId = ?').all(req.params.id)
  const avg_portions = opinions.length
    ? opinions.reduce((s, o) => s + (o.portions || 0), 0) / opinions.length
    : 0
  res.json({
    recipe_name: recipe.name,
    times_prepared: recipe.times_prepared,
    avg_rating: recipe.avg_rating,
    avg_portions,
    total_opinions: recipe.opinion_count,
    history: opinions
  })
})

// DELETE eliminar receta
app.delete('/recipes/:id', (req, res) => {
  const recipe = db.prepare('SELECT * FROM recipes WHERE id = ?').get(req.params.id)
  if (!recipe) return res.status(404).json({ error: 'Not found' })
  db.prepare('DELETE FROM opinions WHERE recipeId = ?').run(req.params.id)
  db.prepare('DELETE FROM recipes WHERE id = ?').run(req.params.id)
  res.json({ message: 'Receta eliminada' })
})

app.listen(3000, '0.0.0.0', () => console.log('Servidor corriendo en puerto 3000'))